
####表格制作####
rm(list=ls())
setwd('D:/科研/GBD/亚洲乳牙/亚洲地图') ##设置工作路径
library(ggmap)
library(maps)
library(dplyr)
CE <- read.csv('亚洲48国家乳牙.csv',header = T)  ## 读取我们的数据
CE$location[CE$location == 'Russian Federation'] = 'Russia'

CE$location[CE$location == 'Congo'] = 'Republic of Congo'
CE$location[CE$location == "Iran (Islamic Republic of)"] = 'Iran'
CE$location[CE$location == "Democratic People's Republic of Korea"] = 'North Korea'
CE$location[CE$location == "Taiwan (Province of China)"] = 'Taiwan'
CE$location[CE$location == "Republic of Korea"] = 'South Korea'
CE$location[CE$location == "United Republic of Tanzania"] = 'Tanzania'

CE$location[CE$location == "Bolivia (Plurinational State of)"] = 'Bolivia'
CE$location[CE$location == "Venezuela (Bolivarian Republic of)"] = 'Venezuela'
CE$location[CE$location == "Czechia"] = 'Czech Republic'
CE$location[CE$location == "Republic of Moldova"] = 'Moldova'
CE$location[CE$location == "Viet Nam"] = 'Vietnam'
CE$location[CE$location == "Lao People's Democratic Republic"] = 'Laos'
CE$location[CE$location == "Syrian Arab Republic"] = 'Syria'
CE$location[CE$location == "North Macedonia"] = 'Macedonia'
CE$location[CE$location == "Micronesia (Federated States of)"] = 'Micronesia'
CE$location[CE$location == "Palestine"] = 'State of Palestine'

CE$location[CE$location == "Bahamas"] = 'The Bahamas'
CE$location[CE$location == "Guinea-Bissau"] = 'Guinea Bissau'


CE$location[CE$location == "Cabo Verde"] = 'Cape Verde'
CE$location[CE$location == "Guyane fran?aise"] = 'Guyane française'
CE$location[CE$location == "Timor-Leste"] = 'East Timor'

CE$location[CE$location == "C么te d'Ivoire"] = 'Ivory Coast'

CE$location[CE$location == "Eswatini"] = 'Swaziland'
CE$location[CE$location == "Brunei Darussalam"] = 'Brunei'
#CE$location[CE$location == "Netherlands"] = 'Sint Maarten'

mapIn<-subset(CE,CE$age=='<5 years' & 
               CE$metric== 'Rate' &
                year=='2023'&
               CE$measure=='Incidence'&
               sex=='Both'&
               CE$cause=='Caries of deciduous teeth')

mapPre<-subset(CE,CE$age=='<5 years' & 
                CE$metric== 'Rate' &
                 year=='2023'&
                CE$measure=='Prevalence'&
                sex=='Both'&
                CE$cause=='Caries of deciduous teeth')
mapDALY<-subset(CE,CE$age=='<5 years' & 
                 CE$metric== 'Rate' &
                 year=='2023'&
                 CE$measure=='DALYs (Disability-Adjusted Life Years)'&
                 sex=='Both'&
                 CE$cause=='Caries of deciduous teeth')
mapIn <- mapIn[,c(2,8)]
mapPre <- mapPre[,c(2,8)]
mapDALY <- mapDALY[,c(2,8)]
write.csv(mapIn,"mapIn.csv")
write.csv(mapPre,"mapPre.csv")
write.csv(mapDALY,"mapDALY.csv")
