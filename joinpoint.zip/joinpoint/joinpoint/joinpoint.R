
####表格制作####
rm(list=ls())
setwd('D:/科研/GBD/亚洲乳牙/joinpoint') ##设置工作路径
library(ggmap)
library(rgdal)
library(maps)
library(dplyr)
CE <- read.csv('亚洲48国家乳牙.csv',header = T)  ## 读取我们的数据

CentralIn<-subset(CE,CE$age=='<5 years' & 
CE$metric== 'Rate' &
 CE$measure=='Incidence'&
               sex=='Both'&
               location%in%c('Kazakhstan','Kyrgyzstan','Tajikistan','Turkmenistan','Uzbekistan')&
               CE$cause=='Caries of deciduous teeth')
CentralIn$insd <- (CentralIn$upper-CentralIn$lower)/3.92
CentralPre<-subset(CE,CE$age=='<5 years' & 
                    CE$metric== 'Rate' &
                    CE$measure=='Prevalence'&
                    sex=='Both'&
                    location%in%c('Kazakhstan','Kyrgyzstan','Tajikistan','Turkmenistan','Uzbekistan')&
                    CE$cause=='Caries of deciduous teeth')
CentralPre$presd <- (CentralPre$upper-CentralPre$lower)/3.92
CentralDALY<-subset(CE,CE$age=='<5 years' & 
                    CE$metric== 'Rate' &
                    CE$measure=='DALYs (Disability-Adjusted Life Years)'&
                    sex=='Both'&
                    location%in%c('Kazakhstan','Kyrgyzstan','Tajikistan','Turkmenistan','Uzbekistan')&
                    CE$cause=='Caries of deciduous teeth')
CentralDALY$dalysd <- (CentralDALY$upper-CentralDALY$lower)/3.92
CentralIn <- CentralIn[,c(2,7,8,11)]
CentralPre <- CentralPre[,c(2,7,8,11)]
CentralDALY <- CentralDALY[,c(2,7,8,11)]
Central <- merge(CentralIn,CentralPre,by=c('location','year'))
Central <- merge(Central,CentralDALY,by=c('location','year'))


EastIn<-subset(CE,CE$age=='<5 years' & 
 CE$metric== 'Rate' &
     CE$measure=='Incidence'&
         sex=='Both'&
      location%in%c('China',"Democratic People's Republic of Korea",'Japan','Mongolia','Republic of Korea')&
                      CE$cause=='Caries of deciduous teeth') 
EastIn$sd <- (EastIn$upper-EastIn$lower)/3.92
EastPre<-subset(CE,CE$age=='<5 years' & 
                 CE$metric== 'Rate' &
                 CE$measure=='Prevalence'&
                 sex=='Both'&
                 location%in%c('China',"Democratic People's Republic of Korea",'Japan','Mongolia','Republic of Korea')&
                 CE$cause=='Caries of deciduous teeth') 
EastPre$sd <- (EastPre$upper-EastPre$lower)/3.92
EastDALY<-subset(CE,CE$age=='<5 years' & 
                 CE$metric== 'Rate' &
                 CE$measure=='DALYs (Disability-Adjusted Life Years)'&
                 sex=='Both'&
                 location%in%c('China',"Democratic People's Republic of Korea",'Japan','Mongolia','Republic of Korea')&
                 CE$cause=='Caries of deciduous teeth') 
EastDALY$sd <- (EastDALY$upper-EastDALY$lower)/3.92
EastIn <- EastIn[,c(2,7,8,11)]
EastPre <- EastPre[,c(2,7,8,11)]
EastDALY <- EastDALY[,c(2,7,8,11)]
East <- merge(EastIn,EastPre,by=c('location','year'))
East <- merge(East,EastDALY,by=c('location','year'))

SoutheastIn<-subset(CE,CE$age=='<5 years' & 
          CE$metric== 'Rate' &
          CE$measure=='Incidence'&
         sex=='Both'&
   location%in%c('Brunei Darussalam','Cambodia','Indonesia',"Lao People's Democratic Republic",
                 'Malaysia','Myanmar','Philippines','Singapore','Thailand','Timor-Leste','Viet Nam')&
        CE$cause=='Caries of deciduous teeth')  
SoutheastIn$sd <- (SoutheastIn$upper-SoutheastIn$lower)/3.92
SoutheastPre<-subset(CE,CE$age=='<5 years' & 
                      CE$metric== 'Rate' &
                      CE$measure=='Prevalence'&
                      sex=='Both'&
                      location%in%c('Brunei Darussalam','Cambodia','Indonesia',"Lao People's Democratic Republic",
                                    'Malaysia','Myanmar','Philippines','Singapore','Thailand','Timor-Leste','Viet Nam')&
                      CE$cause=='Caries of deciduous teeth') 
SoutheastPre$sd <- (SoutheastPre$upper-SoutheastPre$lower)/3.92
SoutheastDALY<-subset(CE,CE$age=='<5 years' & 
          CE$metric== 'Rate' &
          CE$measure=='DALYs (Disability-Adjusted Life Years)'&
         sex=='Both'&
   location%in%c('Brunei Darussalam','Cambodia','Indonesia',"Lao People's Democratic Republic",
                 'Malaysia','Myanmar','Philippines','Singapore','Thailand','Timor-Leste','Viet Nam')&
        CE$cause=='Caries of deciduous teeth')    
SoutheastDALY$sd <- (SoutheastDALY$upper-SoutheastDALY$lower)/3.92

SoutheastIn <- SoutheastIn[,c(2,7,8,11)]
SoutheastPre <- SoutheastPre[,c(2,7,8,11)]
SoutheastDALY <- SoutheastDALY[,c(2,7,8,11)]
Southeast <- merge(SoutheastIn,SoutheastPre,by=c('location','year'))
Southeast <- merge(Southeast,SoutheastDALY,by=c('location','year'))


SouthIn<-subset(CE,CE$age=='<5 years' & 
                      CE$metric== 'Rate' &
                      CE$measure=='Incidence'&
                      sex=='Both'&
                      location%in%c('Afghanistan','Bangladesh','Bhutan','India',
    'Iran (Islamic Republic of)','Maldives','Nepal','Pakistan','Sri Lanka')&
                      CE$cause=='Caries of deciduous teeth')     
SouthIn$sd <- (SouthIn$upper-SouthIn$lower)/3.92
SouthPre<-subset(CE,CE$age=='<5 years' & 
                  CE$metric== 'Rate' &
                  CE$measure=='Prevalence'&
                  sex=='Both'&
                  location%in%c('Afghanistan','Bangladesh','Bhutan','India',
                                'Iran (Islamic Republic of)','Maldives','Nepal','Pakistan','Sri Lanka')&
                  CE$cause=='Caries of deciduous teeth')     
SouthPre$sd <- (SouthPre$upper-SouthPre$lower)/3.92
SouthDALY<-subset(CE,CE$age=='<5 years' & 
                  CE$metric== 'Rate' &
                  CE$measure=='DALYs (Disability-Adjusted Life Years)'&
                  sex=='Both'&
                  location%in%c('Afghanistan','Bangladesh','Bhutan','India',
                                'Iran (Islamic Republic of)','Maldives','Nepal','Pakistan','Sri Lanka')&
                  CE$cause=='Caries of deciduous teeth')     
SouthDALY$sd <- (SouthDALY$upper-SouthDALY$lower)/3.92
SouthIn <- SouthIn[,c(2,7,8,11)]
SouthPre <- SouthPre[,c(2,7,8,11)]
SouthDALY <- SouthDALY[,c(2,7,8,11)]
South <- merge(SouthIn,SouthPre,by=c('location','year'))
South <- merge(South,SouthDALY,by=c('location','year'))


WestIn<-subset(CE,CE$age=='<5 years' & 
                  CE$metric== 'Rate' &
                  CE$measure=='Incidence'&
                  sex=='Both'&
                  location%in%c('Armenia','Azerbaijan','Bahrain','Cyprus',
                                'Georgia','Iraq','Israel','Jordan','Kuwait',
                                'Lebanon','Oman','Qatar','Saudi Arabia',
                                'Palestine','Syrian Arab Republic','Turkye','United Arab Emirates','Yemen')&
                  CE$cause=='Caries of deciduous teeth')   
WestIn$sd <- (WestIn$upper-WestIn$lower)/3.92
WestPre<-subset(CE,CE$age=='<5 years' & 
                 CE$metric== 'Rate' &
                 CE$measure=='Prevalence'&
                 sex=='Both'&
                 location%in%c('Armenia','Azerbaijan','Bahrain','Cyprus',
                               'Georgia','Iraq','Israel','Jordan','Kuwait',
                               'Lebanon','Oman','Qatar','Saudi Arabia',
                               'Palestine','Syrian Arab Republic','Turkye','United Arab Emirates','Yemen')&
                 CE$cause=='Caries of deciduous teeth')   
WestPre$sd <- (WestPre$upper-WestPre$lower)/3.92
WestDALY<-subset(CE,CE$age=='<5 years' & 
                 CE$metric== 'Rate' &
                 CE$measure=='DALYs (Disability-Adjusted Life Years)'&
                 sex=='Both'&
                 location%in%c('Armenia','Azerbaijan','Bahrain','Cyprus',
                               'Georgia','Iraq','Israel','Jordan','Kuwait',
                               'Lebanon','Oman','Qatar','Saudi Arabia',
                               'Palestine','Syrian Arab Republic','Turkye','United Arab Emirates','Yemen')&
                 CE$cause=='Caries of deciduous teeth')   
WestDALY$sd <- (WestDALY$upper-WestDALY$lower)/3.92
WestIn <- WestIn[,c(2,7,8,11)]
WestPre <- WestPre[,c(2,7,8,11)]
WestDALY <- WestDALY[,c(2,7,8,11)]
West <- merge(WestIn,WestPre,by=c('location','year'))
West <- merge(West,WestDALY,by=c('location','year'))


write.csv(Central,"join_Central.csv")
write.csv(East,"join_East.csv")
write.csv(Southeast,"join_Southeast.csv")
write.csv(South,"join_South.csv")
write.csv(West,"join_West.csv")

