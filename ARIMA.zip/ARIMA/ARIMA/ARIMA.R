library(forecast)
library(tseries)
library(ggplot2)
library(reshape2)
library(scales)
# ==========================================

# ==========================================
setwd("D:/科研/GBD/亚洲乳牙/ARIMA")
df <- read.csv("ARIMA2.csv")
regions <- c("Central_Asia", "Southeast_Asia", "East_Asia", "South_Asia", "West_Asia", "Asia")
last_year <- max(df$Year) # 2023

# ==========================================
# 1. 独立模块：计算验证集的 RMSE 和 MAPE
# ==========================================
train_year_end <- 2021
df_train <- subset(df, Year <= train_year_end)
df_test <- subset(df, Year > train_year_end) # 2022-2023数据

accuracy_results <- list()

for (region in regions) {

  ts_train <- ts(df_train[[region]], start = min(df_train$Year), frequency = 1)
  fit_val <- auto.arima(ts_train)
  

  fc_val <- forecast(fit_val, h = last_year - train_year_end)
  

  ts_test <- ts(df_test[[region]], start = train_year_end + 1, frequency = 1)
  

  acc <- accuracy(fc_val, ts_test)

  rmse_val <- acc[2, "RMSE"]
  mape_val <- acc[2, "MAPE"]

  actual_mean <- mean(ts_test)
  nrmse_val <- (rmse_val / actual_mean) * 100

  metrics <- data.frame(
    Region = region,
    RMSE = sprintf("%.2f", rmse_val),
    NRMSE_Percent = sprintf("%.2f", nrmse_val),
    MAPE_Percent = sprintf("%.2f", mape_val)
  )
  accuracy_results[[length(accuracy_results) + 1]] <- metrics
}


df_metrics <- do.call(rbind, accuracy_results)

print(df_metrics)


# ==========================================
# 2. 
# ==========================================
target_year <- 2040
forecast_steps <- target_year - last_year  

df_fcst_list <- list()

for (region in regions) {
 
  ts_data <- ts(df[[region]], start = min(df$Year), frequency = 1)
  fit_final <- auto.arima(ts_data)
  

  fc_final <- forecast(fit_final, h = forecast_steps, level = 95)
  
  temp_df <- data.frame(
    Year = (last_year + 1):target_year,
    Region = region,
    Value = as.numeric(fc_final$mean),         
    Lower = as.numeric(fc_final$lower[, 1]),   
    Upper = as.numeric(fc_final$upper[, 1]),   
    Type = "预测数据"
  )
  df_fcst_list[[length(df_fcst_list) + 1]] <- temp_df
}
df_forecast <- do.call(rbind, df_fcst_list)

# ==========================================
# 3.========================

df_hist <- melt(df, id.vars = "Year", variable.name = "Region", value.name = "Value")
df_hist$Type <- "历史数据"
df_hist$Lower <- NA
df_hist$Upper <- NA

df_bridge <- df_hist[df_hist$Year == last_year, ]
df_bridge$Type <- "预测数据"
df_bridge$Lower <- df_bridge$Value
df_bridge$Upper <- df_bridge$Value

df_final <- rbind(df_hist, df_bridge, df_forecast)


df_final$Region <- gsub("_", " ", df_final$Region)
df_final$Region <- factor(df_final$Region, 
                          levels = c("Asia", "East Asia", "Southeast Asia", 
                                     "South Asia", "Central Asia", "West Asia"))

# ==========================================
# 4. 
# ==========================================
plot_2040 <- ggplot(df_final, aes(x = Year, y = Value, color = Region, 
                                  group = interaction(Region, Type))) +
  

  geom_ribbon(aes(ymin = Lower, ymax = Upper, fill = Region), alpha = 0.15, color = NA) +
  

  geom_line(aes(linetype = Type), linewidth = 0.8) +
  

  scale_color_manual(values = c("Asia" = "black", "East Asia" = "#E41A1C", 
                                "Southeast Asia" = "#377EB8", "South Asia" = "#4DAF4A", 
                                "Central Asia" = "#984EA3", "West Asia" = "#FF7F00")) +
  scale_fill_manual(values = c("Asia" = "black", "East Asia" = "#E41A1C", 
                               "Southeast Asia" = "#377EB8", "South Asia" = "#4DAF4A", 
                               "Central Asia" = "#984EA3", "West Asia" = "#FF7F00"),
                    guide = "none") +
  
  scale_linetype_manual(values = c("历史数据" = "solid", "预测数据" = "dashed"), guide = "none") +
  

  scale_x_continuous(breaks = seq(1990, 2040, by = 5)) +
  
  scale_y_continuous(labels = function(x) x / 1000000) +
  

  labs(
    x = "Year",
    y = "Number of cases in millions", # 加上 (Millions) 提示读者单位
    color = "Region"   
  ) +
 
  
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
    legend.position = "right",
    legend.title = element_text(face = "bold"),
    panel.grid.minor.x = element_blank() 
  )


print(plot_2040)

write.csv(df_final,"Asia 2040 Incident cases.csv")

