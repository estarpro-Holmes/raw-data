library(tidyverse)
library(ggmap)
library(rgdal)
library(maps)
library(dplyr)

library(stringr)
library(ggplot2)
library(tidyr)
library(dplyr)
library(scales)

setwd("D:/科研/GBD/亚洲乳牙/男女性别图")
df <- read.csv("性别.csv")
df_line <- df %>%
  pivot_longer(cols = -Year, names_to = c("Measure", "Sex"), names_sep = "_", values_to = "UI_String") %>%
  mutate(
    UI_String = str_replace_all(UI_String, ",", ""),
    Mean = as.numeric(str_extract(UI_String, "^[0-9\\.]+")),
    Lower = as.numeric(str_extract(UI_String, "(?<=\\()[0-9\\.]+")),
    Upper = as.numeric(str_extract(UI_String, "[0-9\\.]+(?=\\))")),
    Measure = factor(Measure, levels = c("Prevalence", "Incidence"))
  )

# 2. 绘制带半透明 UI 阴影带的折线图
p_line <- ggplot(df_line, aes(x = Year, y = Mean, color = Sex, fill = Sex)) +
  # 绘制阴影带 (95% UI)
  geom_ribbon(aes(ymin = Lower, ymax = Upper), alpha = 0.3, color = NA) +
  # 绘制中心趋势线
  geom_line(linewidth = 1) +
  # 上下分面展示患病率和发病率
  facet_wrap(~ Measure, scales = "free_y", ncol = 1,
             labeller = as_labeller(c(Prevalence = "Prevalence ", 
                                      Incidence = "Incidence"))) +
  # 设置配色
  scale_color_manual(values = c("Female" = "#FF69B4", "Male" = "#4682B4")) +
  scale_fill_manual(values = c("Female" = "#FFB6C1", "Male" = "#ADD8E6")) +
  scale_y_continuous(labels = scales::label_number(big.mark = "")) +
  labs(x = "Year", y = "") +
  theme_minimal(base_size = 12) +
  theme(
    legend.position = "top",
    strip.text = element_text(size = 14, face = "bold", margin = margin(b = 10)),
    axis.title = element_text(face = "bold")
  ) +
  scale_x_continuous(breaks = seq(1990, 2025, by = 5)) +
  labs(x = "Year", y = "") +
  theme_minimal(base_size = 12) +
  theme(
    legend.position = "top",
    strip.text = element_text(size = 14, face = "bold", margin = margin(b = 10)),
    axis.title = element_text(face = "bold")
  )
  

print(p_line)
ggsave("Gender_UI_Overlap_Check.tiff", plot = p_line, width = 8, height = 10, dpi = 300)