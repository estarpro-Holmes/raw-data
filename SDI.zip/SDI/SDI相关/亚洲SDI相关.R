
setwd('D:/科研/GBD/亚洲乳牙/SDI相关') #
library(reshape)
library(ggplot2)
library(ggrepel)


#### figure 4B
EC <- read.csv('亚洲48国家乳牙.csv',header = T)  #
Case<-subset(EC,EC$age=='<5 years' & 
               EC$metric== 'Number' &
               EC$measure=='DALYs (Disability-Adjusted Life Years)'&
               sex=='Both'&
               year=='2023'&
               cause=='Caries of deciduous teeth')
EC<-subset(EC,EC$age=='<5 years' & 
                    metric== 'Rate' &
                    measure=='DALYs (Disability-Adjusted Life Years)'&
                    sex=='Both'&
                    year=='2023'&
                    cause=='Caries of deciduous teeth')

SDI <- read.csv('SDI2023.csv',header = T)
SDI<-SDI[,-2]
SDI<-SDI[,-2]

SDI <- melt(SDI,id='location')
SDI$variable <- as.numeric(gsub('\\X',replacement = '', SDI$variable))
names(SDI) <- c('location','year','SDI')
SDI <- SDI[SDI$year== 2023,] ###ֻȡ2019????????



###?ϲ?��??????
EC_ASR_SDI_2023 <- merge(EC,SDI,by=c('location','year'))
EC_ASR_SDI_2023 <- merge(EC_ASR_SDI_2023,Case,by=c('location','year'))
names(EC_ASR_SDI_2023)[8]<-'DALYs'
names(EC_ASR_SDI_2023)[17]<-'Cases'
##??ͼ
EC_ASR_SDI_2023$Cases<- round(EC_ASR_SDI_2023$Cases,0) 
##发病患病


## 画图
ggplot(EC_ASR_SDI_2023, aes(x = SDI, y = DALYs)) + 
  geom_point(aes(size = Cases, color = location), alpha = 0.5) + 
  geom_text_repel(aes(label = location, color = location), 
                  size = 1.5, fontface = 'bold', max.overlaps = 160) +
  
  # 此处将 se = FALSE 改为了 se = TRUE，并添加了阴影格式设置
  geom_smooth(colour = '#000000FF', stat = "smooth", method = 'loess', 
              se = TRUE, level = 0.95, fill = "gray70", alpha = 0.3, span = 0.5) +
  
  scale_size_binned(
    name = 'Cases', 
    breaks = c(5, 10, 100, 1000, 10000),
    labels = function(x) format(x, scientific = FALSE) # 关键修改
  )+
  theme_bw() + 
  theme(legend.position = "right") +
  guides(color = "none")

  