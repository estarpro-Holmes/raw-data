
####表格制作####
rm(list=ls())
setwd('D:/科研/GBD/亚洲乳牙/表格') ##设置工作路径
library(ggmap)
library(rgdal)
library(maps)
library(dplyr)
CE <- read.csv('亚洲48国家乳牙.csv',header = T)  ## 读取我们的数据

Change<-read.csv('change.csv',header=T)


## Prevalence ##
EAPC <- subset(CE, CE$age=='<5 years' & 
                 CE$metric== 'Rate' &
                 CE$measure=='Prevalence')
EAPC <- EAPC[,c(2,7,8)] ##获取地区、年份以及对应的数值
order<-read.csv('亚洲国家order.csv',header=T)
country <- order
EAPC_cal <- data.frame(location=country,EAPC=rep(0,times=48),UCI=rep(0,times=48),LCI=rep(0,times=48)) 
for (i in 1:48){  ###总共48个地区，所以循环48次
  country_cal <- as.character(EAPC_cal[i,1]) ### 依次取对应的地区
  a <- subset(EAPC, EAPC$location==country_cal)  ##取对应地区的数据子集
  a$y <- log(a$val)  ##根据EAPC计算方法计算y值
  mod_simp_reg<-lm(y~year,data=a) ##根据EAPC计算方法做线性回归方程
  estimate <- (exp(summary(mod_simp_reg)[["coefficients"]][2,1])-1)*100 ##根据EAPC计算方法取方程beta值来计算EAPC
  low <- (exp(summary(mod_simp_reg)[["coefficients"]][2,1]-1.96*summary(mod_simp_reg)[["coefficients"]][2,2])-1)*100
  ### 计算EAPC的95%可信区间的上限值
  high <- (exp(summary(mod_simp_reg)[["coefficients"]][2,1]+1.96*summary(mod_simp_reg)[["coefficients"]][2,2])-1)*100
  ### 计算EAPC的95%可信区间的下限值
  EAPC_cal[i,2] <- estimate
  EAPC_cal[i,4] <- low
  EAPC_cal[i,3] <- high
}

EAPC_cal$EAPC <- round(EAPC_cal$EAPC,2)  ##保留2位小数点
EAPC_cal$UCI <- round(EAPC_cal$UCI,2)
EAPC_cal$LCI <- round(EAPC_cal$LCI,2)
EAPC_cal$EAPC_CI <- paste(EAPC_cal$LCI,EAPC_cal$UCI,sep = '-') 
EAPC_cal$EAPC_CI <- paste(EAPC_cal$EAPC_CI,')',sep = '') 
EAPC_cal$EAPC_CI <- paste('(',EAPC_cal$EAPC_CI,sep = '') 
EAPC_cal$EAPC_CI <- paste(EAPC_cal$EAPC,EAPC_cal$EAPC_CI,sep = ' ')  

## 1990 ASR
ASR_1990 <- subset(CE,CE$year==1990 & 
                     CE$age=='<5 years' & 
                     CE$metric== 'Rate' &
                     sex=='Both'&
                     CE$measure=='Prevalence')

ASR_1990 <- ASR_1990[,c(2,8,9,10)]  ### 只取需要的变量：地区以及对应的数值
ASR_1990$val <- round(ASR_1990$val,2)  ###取整
ASR_1990$lower <- round(ASR_1990$lower,2)###取整
ASR_1990$upper <- round(ASR_1990$upper,2) ###取整
ASR_1990$ASR_1990 <- paste(ASR_1990$lower,ASR_1990$upper,sep = '-') ## 用-连接95%UI上下数值
ASR_1990$ASR_1990 <- paste(ASR_1990$ASR_1990,')',sep = '')  ##95%UI前后加括号             
ASR_1990$ASR_1990 <- paste('(',ASR_1990$ASR_1990,sep = '')  ##95%UI前后加括号
ASR_1990$ASR_1990 <- paste(ASR_1990$val,ASR_1990$ASR_1990,sep = ' ') ##数据和95%UI用空格键连接


## 2023 ASR
ASR_2023 <- subset(CE,CE$year==2023 & 
                     CE$age=='<5 years' & 
                     CE$metric== 'Rate' &
                     sex=='Both'&
                     CE$measure=='Prevalence')

ASR_2023 <- ASR_2023[,c(2,8,9,10)]  ### 只取需要的变量：地区以及对应的数值
ASR_2023$val <- round(ASR_2023$val,2)  ###取整
ASR_2023$lower <- round(ASR_2023$lower,2)###取整
ASR_2023$upper <- round(ASR_2023$upper,2) ###取整
ASR_2023$ASR_2023 <- paste(ASR_2023$lower,ASR_2023$upper,sep = '-') ## 用-连接95%UI上下数值
ASR_2023$ASR_2023 <- paste(ASR_2023$ASR_2023,')',sep = '')  ##95%UI前后加括号             
ASR_2023$ASR_2023 <- paste('(',ASR_2023$ASR_2023,sep = '')  ##95%UI前后加括号
ASR_2023$ASR_2023 <- paste(ASR_2023$val,ASR_2023$ASR_2023,sep = ' ') ##数据和95%UI用空格键连接

## CE_change
change_ASR <- subset(Change, Change$age=='<5 years' & 
                         Change$metric== 'Rate' &
                       sex=='Both'&
                         Change$measure=='Prevalence')

change_ASR <- change_ASR[,c(2,9,10,11)]  ### 只取需要的变量：地区以及对应的数值
change_ASR$val <- round(change_ASR$val,2)  ###取整
change_ASR$lower <- round(change_ASR$lower,2)###取整
change_ASR$upper <- round(change_ASR$upper,2) ###取整
change_ASR$change_ASR <- paste(change_ASR$lower,change_ASR$upper,sep = '-') ## 用-连接95%UI上下数值
change_ASR$change_ASR <- paste(change_ASR$change_ASR,')',sep = '')  ##95%UI前后加括号             
change_ASR$change_ASR <- paste('(',change_ASR$change_ASR,sep = '')  ##95%UI前后加括号
change_ASR$change_ASR <- paste(change_ASR$val,change_ASR$change_ASR,sep = ' ') ##数据和95%UI用空格键连接
### 数据整合 ###取地区和整合好的变量
ASR_1990 <- ASR_1990[,c(1,5)]
ASR_2023 <- ASR_2023[,c(1,5)]
change_ASR <- change_ASR[,c(1,5)]
EAPC_cal <- EAPC_cal[,c(1,5)]

Prevalence <- merge(ASR_1990,ASR_2023,by='location')
Prevalence <- merge(Prevalence,change_ASR,by='location')
names(EAPC_cal)[1] <- 'location'
Prevalence <- merge(Prevalence,EAPC_cal,by='location')

write.csv(Prevalence,"Prevalence表格.csv")
# 

###DALYs#####

## 1990 DALYs


DALYs_1990 <- subset(CE,CE$year==1990 & 
                       CE$age=='<5 years' & 
                       CE$metric== 'Rate' &
                       sex=='Both'&
                       CE$measure=='DALYs (Disability-Adjusted Life Years)')

DALYs_1990 <- DALYs_1990[,c(2,8,9,10)]  ### 只取需要的变量：地区以及对应的数值
DALYs_1990$val <- round(DALYs_1990$val,2)  ###取整
DALYs_1990$lower <- round(DALYs_1990$lower,2)###取整
DALYs_1990$upper <- round(DALYs_1990$upper,2) ###取整
DALYs_1990$DALYs_1990 <- paste(DALYs_1990$lower,DALYs_1990$upper,sep = '-') ## 用-连接95%UI上下数值
DALYs_1990$DALYs_1990 <- paste(DALYs_1990$DALYs_1990,')',sep = '')  ##95%UI前后加括号             
DALYs_1990$DALYs_1990 <- paste('(',DALYs_1990$DALYs_1990,sep = '')  ##95%UI前后加括号
DALYs_1990$DALYs_1990 <- paste(DALYs_1990$val,DALYs_1990$DALYs_1990,sep = ' ') ##数据和95%UI用空格键连接


## 2023 DALYs
DALYs_2023 <- subset(CE,CE$year==2023 & 
                       CE$age=='<5 years' & 
                       CE$metric== 'Rate' &
                       sex=='Both'&
                       CE$measure=='DALYs (Disability-Adjusted Life Years)')

DALYs_2023 <- DALYs_2023[,c(2,8,9,10)]  ### 只取需要的变量：地区以及对应的数值
DALYs_2023$val <- round(DALYs_2023$val,2)  ###取整
DALYs_2023$lower <- round(DALYs_2023$lower,2)###取整
DALYs_2023$upper <- round(DALYs_2023$upper,2) ###取整
DALYs_2023$DALYs_2023 <- paste(DALYs_2023$lower,DALYs_2023$upper,sep = '-') ## 用-连接95%UI上下数值
DALYs_2023$DALYs_2023 <- paste(DALYs_2023$DALYs_2023,')',sep = '')  ##95%UI前后加括号             
DALYs_2023$DALYs_2023 <- paste('(',DALYs_2023$DALYs_2023,sep = '')  ##95%UI前后加括号
DALYs_2023$DALYs_2023 <- paste(DALYs_2023$val,DALYs_2023$DALYs_2023,sep = ' ') ##数据和95%UI用空格键连接
Change<-read.csv('DALYchange.csv',header=T)
## CE_change
change_DALYs <- subset(Change, Change$age=='<5 years' & 
                         Change$metric== 'Rate' &
                         sex=='Both'&
                         Change$measure=='DALYs (Disability-Adjusted Life Years)')

change_DALYs <- change_DALYs[,c(2,9,10,11)]  ### 只取需要的变量：地区以及对应的数值
change_DALYs$val <- round(change_DALYs$val,2)  ###取整
change_DALYs$lower <- round(change_DALYs$lower,2)###取整
change_DALYs$upper <- round(change_DALYs$upper,2) ###取整
change_DALYs$change_DALYs <- paste(change_DALYs$lower,change_DALYs$upper,sep = '-') ## 用-连接95%UI上下数值
change_DALYs$change_DALYs <- paste(change_DALYs$change_DALYs,')',sep = '')  ##95%UI前后加括号             
change_DALYs$change_DALYs <- paste('(',change_DALYs$change_DALYs,sep = '')  ##95%UI前后加括号
change_DALYs$change_DALYs <- paste(change_DALYs$val,change_DALYs$change_DALYs,sep = ' ') ##数据和95%UI用空格键连接



## EAPC ##
EAPC_DALYs <- subset(CE, CE$age=='<5 years' & 
                       CE$metric== 'Rate' &
                       sex=='Both'&
                       CE$measure=='DALYs (Disability-Adjusted Life Years)')
EAPC_DALYs <- EAPC_DALYs[,c(2,7,8)] ##获取地区、年份以及对应的数值



country <- order
EAPC_Dalys <- data.frame(location=country,EAPC_DALYs=rep(0,times=48),UCI=rep(0,times=48),LCI=rep(0,times=48)) 
for (i in 1:48){  ###总共48个地区，所以循环48次
  country_Dalys <- as.character(EAPC_Dalys[i,1]) ### 依次取对应的地区
  a <- subset(EAPC_DALYs, EAPC_DALYs$location==country_Dalys)  ##取对应地区的数据子集
  a$y <- log(a$val)  ##根据EAPC计算方法计算y值
  mod_simp_reg<-lm(y~year,data=a) ##根据EAPC计算方法做线性回归方程
  estimate <- (exp(summary(mod_simp_reg)[["coefficients"]][2,1])-1)*100 ##根据EAPC计算方法取方程beta值来计算EAPC
  low <- (exp(summary(mod_simp_reg)[["coefficients"]][2,1]-1.96*summary(mod_simp_reg)[["coefficients"]][2,2])-1)*100
  ### 计算EAPC的95%可信区间的上限值
  high <- (exp(summary(mod_simp_reg)[["coefficients"]][2,1]+1.96*summary(mod_simp_reg)[["coefficients"]][2,2])-1)*100
  ### 计算EAPC的95%可信区间的下限值
  EAPC_Dalys[i,2] <- estimate
  EAPC_Dalys[i,4] <- low
  EAPC_Dalys[i,3] <- high
}

EAPC_Dalys$EAPC_DALYs <- round(EAPC_Dalys$EAPC_DALYs,2)  ##保留2位小数点
EAPC_Dalys$UCI <- round(EAPC_Dalys$UCI,2)
EAPC_Dalys$LCI <- round(EAPC_Dalys$LCI,2)
EAPC_Dalys$EAPC_DALYsCI <- paste(EAPC_Dalys$LCI,EAPC_Dalys$UCI,sep = '-') 
EAPC_Dalys$EAPC_DALYsCI <- paste(EAPC_Dalys$EAPC_DALYsCI,')',sep = '') 
EAPC_Dalys$EAPC_DALYsCI <- paste('(',EAPC_Dalys$EAPC_DALYsCI,sep = '') 
EAPC_Dalys$EAPC_DALYsCI<- paste(EAPC_Dalys$EAPC_DALYs,EAPC_Dalys$EAPC_DALYsCI,sep = ' ')  

### 数据整合 ###取地区和整合好的变量
DALYs_1990 <- DALYs_1990[,c(1,5)]
DALYs_2023 <- DALYs_2023[,c(1,5)]
change_DALYs <- change_DALYs[,c(1,5)]
EAPC_Dalys <- EAPC_Dalys[,c(1,5)]

DALYs <- merge(DALYs_1990,DALYs_2023,by='location')
DALYs <- merge(DALYs,change_DALYs,by='location')
names(EAPC_Dalys)[1] <- 'location'
DALYs <- merge(DALYs,EAPC_Dalys,by='location')
write.csv(DALYs,"DALYs表格.csv")

###Incidence#####

## 1990 


Incidence_1990 <- subset(CE,CE$year==1990 & 
                      CE$age=='<5 years' & 
                      CE$metric== 'Rate' &
                      sex=='Both'&
                      CE$measure=='Incidence')

Incidence_1990 <- Incidence_1990[,c(2,8,9,10)]  ### 只取需要的变量：地区以及对应的数值
Incidence_1990$val <- round(Incidence_1990$val,2)  ###取整
Incidence_1990$lower <- round(Incidence_1990$lower,2)###取整
Incidence_1990$upper <- round(Incidence_1990$upper,2) ###取整
Incidence_1990$Incidence_1990 <- paste(Incidence_1990$lower,Incidence_1990$upper,sep = '-') ## 用-连接95%UI上下数值
Incidence_1990$Incidence_1990 <- paste(Incidence_1990$Incidence_1990,')',sep = '')  ##95%UI前后加括号             
Incidence_1990$Incidence_1990 <- paste('(',Incidence_1990$Incidence_1990,sep = '')  ##95%UI前后加括号
Incidence_1990$Incidence_1990 <- paste(Incidence_1990$val,Incidence_1990$Incidence_1990,sep = ' ') ##数据和95%UI用空格键连接


## 2023 Incidence
Incidence_2023 <- subset(CE,CE$year==2023 & 
                      CE$age=='<5 years' & 
                      CE$metric== 'Rate' &
                      sex=='Both'&
                      CE$measure=='Incidence')

Incidence_2023 <- Incidence_2023[,c(2,8,9,10)]  ### 只取需要的变量：地区以及对应的数值
Incidence_2023$val <- round(Incidence_2023$val,2)  ###取整
Incidence_2023$lower <- round(Incidence_2023$lower,2)###取整
Incidence_2023$upper <- round(Incidence_2023$upper,2) ###取整
Incidence_2023$Incidence_2023 <- paste(Incidence_2023$lower,Incidence_2023$upper,sep = '-') ## 用-连接95%UI上下数值
Incidence_2023$Incidence_2023 <- paste(Incidence_2023$Incidence_2023,')',sep = '')  ##95%UI前后加括号             
Incidence_2023$Incidence_2023 <- paste('(',Incidence_2023$Incidence_2023,sep = '')  ##95%UI前后加括号
Incidence_2023$Incidence_2023 <- paste(Incidence_2023$val,Incidence_2023$Incidence_2023,sep = ' ') ##数据和95%UI用空格键连接

## CE_change
change_Incidence <- subset(Change, Change$age=='<5 years' & 
                        Change$metric== 'Rate' &
                        sex=='Both'&
                        Change$measure=='Incidence')

change_Incidence <- change_Incidence[,c(2,9,10,11)]  ### 只取需要的变量：地区以及对应的数值
change_Incidence$val <- round(change_Incidence$val,2)  ###取整
change_Incidence$lower <- round(change_Incidence$lower,2)###取整
change_Incidence$upper <- round(change_Incidence$upper,2) ###取整
change_Incidence$change_Incidence <- paste(change_Incidence$lower,change_Incidence$upper,sep = '-') ## 用-连接95%UI上下数值
change_Incidence$change_Incidence <- paste(change_Incidence$change_Incidence,')',sep = '')  ##95%UI前后加括号             
change_Incidence$change_Incidence <- paste('(',change_Incidence$change_Incidence,sep = '')  ##95%UI前后加括号
change_Incidence$change_Incidence <- paste(change_Incidence$val,change_Incidence$change_Incidence,sep = ' ') ##数据和95%UI用空格键连接



## EAPC ##
EAPC_Incidence <- subset(CE, CE$age=='<5 years' & 
                      CE$metric== 'Rate' &
                      sex=='Both'&
                      CE$measure=='Incidence')
EAPC_Incidence <- EAPC_Incidence[,c(2,7,8)] ##获取地区、年份以及对应的数值



country <- order$V1
EAPC_Incidence <- data.frame(location=country,EAPC_Incidence=rep(0,times=48),UCI=rep(0,times=48),LCI=rep(0,times=48)) 
for (i in 1:48){  ###总共48个地区，所以循环48次
  country_Incidence <- as.character(EAPC_Incidence[i,1]) ### 依次取对应的地区
  a <- subset(EAPC_Incidence, EAPC_Incidence$location==country_Incidence)  ##取对应地区的数据子集
  a$y <- log(a$val)  ##根据EAPC计算方法计算y值
  mod_simp_reg<-lm(y~year,data=a) ##根据EAPC计算方法做线性回归方程
  estimate <- (exp(summary(mod_simp_reg)[["coefficients"]][2,1])-1)*100 ##根据EAPC计算方法取方程beta值来计算EAPC
  low <- (exp(summary(mod_simp_reg)[["coefficients"]][2,1]-1.96*summary(mod_simp_reg)[["coefficients"]][2,2])-1)*100
  ### 计算EAPC的95%可信区间的上限值
  high <- (exp(summary(mod_simp_reg)[["coefficients"]][2,1]+1.96*summary(mod_simp_reg)[["coefficients"]][2,2])-1)*100
  ### 计算EAPC的95%可信区间的下限值
  EAPC_Incidence[i,2] <- estimate
  EAPC_Incidence[i,4] <- low
  EAPC_Incidence[i,3] <- high
}

EAPC_Incidence$EAPC_Incidence <- round(EAPC_Incidence$EAPC_Incidence,2)  ##保留2位小数点
EAPC_Incidence$UCI <- round(EAPC_Incidence$UCI,2)
EAPC_Incidence$LCI <- round(EAPC_Incidence$LCI,2)
EAPC_Incidence$EAPC_IncidenceCI <- paste(EAPC_Incidence$LCI,EAPC_Incidence$UCI,sep = '-') 
EAPC_Incidence$EAPC_IncidenceCI <- paste(EAPC_Incidence$EAPC_IncidenceCI,')',sep = '') 
EAPC_Incidence$EAPC_IncidenceCI <- paste('(',EAPC_Incidence$EAPC_IncidenceCI,sep = '') 
EAPC_Incidence$EAPC_IncidenceCI <- paste(EAPC_Incidence$EAPC_Incidence,EAPC_Incidence$EAPC_IncidenceCI,sep = ' ')  

### 数据整合 ###取地区和整合好的变量
Incidence_1990 <- Incidence_1990[,c(1,5)]
Incidence_2023 <- Incidence_2023[,c(1,5)]
change_Incidence <- change_Incidence[,c(1,5)]
EAPC_Incidence <- EAPC_Incidence[,c(1,5)]

Incidence <- merge(Incidence_1990,Incidence_2023,by='location')
Incidence <- merge(Incidence,change_Incidence,by='location')
Incidence <- merge(Incidence,EAPC_Incidence,by='location')




###数据合并#####

Incidence$location <- factor(Incidence$location, levels=order$V1, ordered=TRUE)
DALYs$location <- factor(DALYs$location, levels=order$V1, ordered=TRUE)

Incidence$location <- factor(Incidence$location, levels=order$V1, ordered=TRUE)


data <- merge(Incidence,DALYs,by='location')
data <- merge(data,YLLs,by='location')
data <- merge(data,Incidence,by='location')
data$location <- factor(data$location, levels=order$V1, ordered=TRUE)
data<-arrange(data,data$location)

write.csv(data,"merge_data.csv")
